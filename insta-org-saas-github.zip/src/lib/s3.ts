import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export const s3Client = new S3Client({
  region: process.env.S3_REGION || "us-east-1",
  endpoint: process.env.S3_ENDPOINT || "http://localhost:9000",
  forcePathStyle: true,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID || "minioadmin",
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || "miniopassword123",
  },
});

const BUCKET = process.env.S3_BUCKET_NAME || "insta-private-media";

export async function signUploadUrl(params: {
  storageKey: string;
  mimeType: string;
  sizeBytes: number;
}) {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: params.storageKey,
    ContentType: params.mimeType,
    ContentLength: params.sizeBytes,
  });

  return getSignedUrl(s3Client, command, { expiresIn: 600 });
}

export async function validateUploadedObject(storageKey: string) {
  const command = new HeadObjectCommand({
    Bucket: BUCKET,
    Key: storageKey,
  });

  const head = await s3Client.send(command);
  return {
    exists: true,
    contentLength: head.ContentLength ?? 0,
    contentType: head.ContentType ?? "application/octet-stream",
  };
}

export async function signDownloadUrl(storageKey: string, fileName: string) {
  const command = new GetObjectCommand({
    Bucket: BUCKET,
    Key: storageKey,
    ResponseContentDisposition: `attachment; filename="${encodeURIComponent(fileName)}"`,
  });

  return getSignedUrl(s3Client, command, { expiresIn: 900 });
}
