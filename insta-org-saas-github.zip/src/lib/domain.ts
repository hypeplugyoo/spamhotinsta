import { z } from "zod";
import crypto from "crypto";

export const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "video/mp4",
  "video/quicktime",
] as const;

export const MAX_UPLOAD_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB

export const registerSchema = z.object({
  name: z.string().min(2, "Informe seu nome"),
  email: z.string().email("E-mail inválido"),
  password: z.string().min(8, "A senha deve ter pelo menos 8 caracteres"),
  organizationName: z.string().min(2, "Informe o nome da sua organização"),
});

export const loginSchema = z.object({
  email: z.string().email("E-mail inválido"),
  password: z.string().min(1, "Informe sua senha"),
});

export const createProfileSchema = z.object({
  username: z
    .string()
    .trim()
    .min(1, "Informe o nome de usuário")
    .transform((val) => val.replace(/^@+/, "").toLowerCase())
    .refine((val) => /^[a-z0-9._]{1,30}$/.test(val), {
      message: "Nome de usuário do Instagram inválido",
    }),
  displayName: z.string().trim().optional(),
  instagramPassword: z.string().optional(),
});

export const createGroupSchema = z.object({
  name: z.string().trim().min(2, "O grupo precisa de um nome"),
  description: z.string().trim().optional(),
  profileIds: z.array(z.string()).default([]),
});

export const prepareUploadSchema = z.object({
  fileName: z.string().min(1),
  mimeType: z.enum(ALLOWED_MIME_TYPES, {
    errorMap: () => ({ message: "Formato não suportado. Use JPG, PNG, WEBP ou MP4." }),
  }),
  sizeBytes: z
    .number()
    .int()
    .positive()
    .max(MAX_UPLOAD_SIZE_BYTES, "Arquivo excede o limite de 100MB"),
});

export const verifyUploadSchema = z.object({
  mediaId: z.string().min(1),
});

export function buildOrgStorageKey(organizationId: string, fileName: string): string {
  const sanitized = fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const uniqueId = crypto.randomUUID();
  return `orgs/${organizationId}/media/${uniqueId}-${sanitized}`;
}
