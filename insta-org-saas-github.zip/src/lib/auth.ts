import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { prisma } from "./db";
import { OrgRole } from "@prisma/client";

const COOKIE_NAME = "insta_org_session";
const SECRET = new TextEncoder().encode(
  process.env.SESSION_SECRET || "default-secret-key-change-in-production-32bytes"
);
const SESSION_DURATION_MS = 1000 * 60 * 60 * 24 * 7; // 7 dias

export interface IdentityContext {
  sessionId: string;
  userId: string;
  organizationId: string;
  organizationName: string;
  role: OrgRole;
  userEmail: string;
  userName: string;
}

export async function createSessionCookie(
  userId: string,
  organizationId: string,
  role: OrgRole
) {
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);

  const session = await prisma.session.create({
    data: {
      userId,
      organizationId,
      expiresAt,
    },
  });

  const token = await new SignJWT({
    sid: session.id,
    uid: userId,
    oid: organizationId,
    role,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(SECRET);

  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });

  return session;
}

export async function destroySessionCookie() {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (token) {
    try {
      const { payload } = await jwtVerify(token, SECRET);
      if (payload.sid) {
        await prisma.session.deleteMany({ where: { id: String(payload.sid) } });
      }
    } catch {
      // Ignora token expirado
    }
  }
  cookies().delete(COOKIE_NAME);
}

export async function getIdentity(): Promise<IdentityContext | null> {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;

  try {
    const { payload } = await jwtVerify(token, SECRET);
    const sessionId = String(payload.sid);

    const session = await prisma.session.findUnique({
      where: { id: sessionId },
      include: {
        user: true,
        organization: true,
      },
    });

    if (!session || session.expiresAt < new Date()) {
      return null;
    }

    const membership = await prisma.membership.findUnique({
      where: {
        userId_organizationId: {
          userId: session.userId,
          organizationId: session.organizationId,
        },
      },
    });

    if (!membership) return null;

    return {
      sessionId: session.id,
      userId: session.userId,
      organizationId: session.organizationId,
      organizationName: session.organization.name,
      role: membership.role,
      userEmail: session.user.email,
      userName: session.user.name,
    };
  } catch {
    return null;
  }
}

export async function requireIdentity(
  allowedRoles: OrgRole[] = ["OWNER", "ADMIN", "EDITOR", "VIEWER"]
): Promise<IdentityContext> {
  const identity = await getIdentity();
  if (!identity) {
    throw new Error("UNAUTHORIZED");
  }
  if (!allowedRoles.includes(identity.role)) {
    throw new Error("FORBIDDEN");
  }
  return identity;
}
