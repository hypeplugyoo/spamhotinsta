import { redirect } from "next/navigation";
import { getIdentity } from "@/lib/auth";

export default async function HomePage() {
  const identity = await getIdentity();
  if (identity) {
    redirect("/dashboard");
  }
  redirect("/login");
}
