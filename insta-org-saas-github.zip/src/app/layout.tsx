import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "InstaOrg SaaS — Gestão de Conteúdo Multi-Contas",
  description: "Plataforma Multi-Tenant para gestão de perfis, grupos e mídias privadas no Instagram.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
