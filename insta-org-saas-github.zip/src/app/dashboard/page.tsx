import { redirect } from "next/navigation";
import { getIdentity } from "@/lib/auth";
import { Dashboard } from "@/components/dashboard";

export default async function DashboardPage() {
  const identity = await getIdentity();
  if (!identity) {
    redirect("/login");
  }

  return (
    <Dashboard
      organizationName={identity.organizationName}
      userName={identity.userName}
      userRole={identity.role}
    />
  );
}
