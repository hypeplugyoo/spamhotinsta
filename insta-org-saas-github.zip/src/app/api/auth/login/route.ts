import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db";
import { loginSchema } from "@/lib/domain";
import { createSessionCookie } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = loginSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { email: parsed.data.email },
      include: {
        memberships: {
          include: { organization: true },
          orderBy: { createdAt: "asc" },
        },
      },
    });

    if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
      return NextResponse.json(
        { error: "Credenciais inválidas." },
        { status: 401 }
      );
    }

    const primaryMembership = user.memberships[0];
    if (!primaryMembership) {
      return NextResponse.json(
        { error: "Usuário não pertence a nenhuma organização." },
        { status: 403 }
      );
    }

    await createSessionCookie(
      user.id,
      primaryMembership.organizationId,
      primaryMembership.role
    );

    return NextResponse.json({
      ok: true,
      organization: {
        id: primaryMembership.organization.id,
        name: primaryMembership.organization.name,
      },
    });
  } catch {
    return NextResponse.json({ error: "Erro ao autenticar." }, { status: 500 });
  }
}
