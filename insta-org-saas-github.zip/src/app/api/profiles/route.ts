import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireIdentity } from "@/lib/auth";
import { createProfileSchema } from "@/lib/domain";
import { encryptSecret } from "@/lib/crypto";

export async function GET() {
  try {
    const identity = await requireIdentity();

    const profiles = await prisma.instagramProfile.findMany({
      where: { organizationId: identity.organizationId },
      select: {
        id: true,
        username: true,
        displayName: true,
        isActive: true,
        sessionUpdatedAt: true,
        encryptedPassword: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      profiles: profiles.map((p) => ({
        id: p.id,
        username: p.username,
        displayName: p.displayName,
        isActive: p.isActive,
        hasCredentials: Boolean(p.encryptedPassword),
        sessionUpdatedAt: p.sessionUpdatedAt,
        createdAt: p.createdAt,
      })),
    });
  } catch {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    const identity = await requireIdentity(["OWNER", "ADMIN", "EDITOR"]);
    const body = await request.json();
    const parsed = createProfileSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { username, displayName, instagramPassword } = parsed.data;

    const encryptedPassword =
      instagramPassword && instagramPassword.trim().length > 0
        ? encryptSecret(instagramPassword.trim())
        : null;

    const profile = await prisma.instagramProfile.upsert({
      where: {
        organizationId_username: {
          organizationId: identity.organizationId,
          username,
        },
      },
      update: {
        displayName: displayName || undefined,
        ...(encryptedPassword ? { encryptedPassword } : {}),
      },
      create: {
        organizationId: identity.organizationId,
        username,
        displayName: displayName || `@${username}`,
        encryptedPassword,
      },
    });

    return NextResponse.json({
      profile: {
        id: profile.id,
        username: profile.username,
        displayName: profile.displayName,
        hasCredentials: Boolean(profile.encryptedPassword),
      },
    });
  } catch {
    return NextResponse.json(
      { error: "Erro ao salvar perfil do Instagram." },
      { status: 500 }
    );
  }
}
