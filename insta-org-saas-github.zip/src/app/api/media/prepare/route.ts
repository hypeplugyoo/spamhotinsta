import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireIdentity } from "@/lib/auth";
import { buildOrgStorageKey, prepareUploadSchema } from "@/lib/domain";
import { signUploadUrl } from "@/lib/s3";

export async function POST(request: Request) {
  try {
    const identity = await requireIdentity(["OWNER", "ADMIN", "EDITOR"]);
    const body = await request.json();
    const parsed = prepareUploadSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { fileName, mimeType, sizeBytes } = parsed.data;
    const storageKey = buildOrgStorageKey(identity.organizationId, fileName);

    const media = await prisma.mediaAsset.create({
      data: {
        organizationId: identity.organizationId,
        fileName,
        mimeType,
        sizeBytes,
        storageKey,
        status: "PENDING_UPLOAD",
      },
    });

    const uploadUrl = await signUploadUrl({
      storageKey,
      mimeType,
      sizeBytes,
    });

    return NextResponse.json({
      mediaId: media.id,
      uploadUrl,
    });
  } catch {
    return NextResponse.json(
      { error: "Falha ao preparar upload seguro." },
      { status: 500 }
    );
  }
}
