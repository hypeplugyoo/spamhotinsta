import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireIdentity } from "@/lib/auth";
import { verifyUploadSchema } from "@/lib/domain";
import { validateUploadedObject } from "@/lib/s3";

export async function POST(request: Request) {
  try {
    const identity = await requireIdentity(["OWNER", "ADMIN", "EDITOR"]);
    const body = await request.json();
    const parsed = verifyUploadSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: "ID de mídia inválido." }, { status: 400 });
    }

    const media = await prisma.mediaAsset.findFirst({
      where: {
        id: parsed.data.mediaId,
        organizationId: identity.organizationId,
      },
    });

    if (!media) {
      return NextResponse.json({ error: "Mídia não encontrada." }, { status: 404 });
    }

    try {
      const s3Object = await validateUploadedObject(media.storageKey);

      if (s3Object.contentLength <= 0) {
        throw new Error("EMPTY_OBJECT");
      }

      const updated = await prisma.mediaAsset.update({
        where: { id: media.id },
        data: {
          status: "READY",
          sizeBytes: s3Object.contentLength,
          verifiedAt: new Date(),
        },
      });

      return NextResponse.json({ ok: true, media: updated });
    } catch {
      await prisma.mediaAsset.update({
        where: { id: media.id },
        data: { status: "FAILED" },
      });
      return NextResponse.json(
        { error: "O objeto não foi localizado no armazenamento privado." },
        { status: 422 }
      );
    }
  } catch {
    return NextResponse.json({ error: "Erro ao verificar mídia." }, { status: 500 });
  }
}
