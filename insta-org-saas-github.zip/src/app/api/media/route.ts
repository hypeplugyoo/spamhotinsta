import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireIdentity } from "@/lib/auth";
import { signDownloadUrl } from "@/lib/s3";

export async function GET() {
  try {
    const identity = await requireIdentity();

    const items = await prisma.mediaAsset.findMany({
      where: {
        organizationId: identity.organizationId,
        status: "READY",
      },
      orderBy: { createdAt: "desc" },
    });

    const mediaWithSignedLinks = await Promise.all(
      items.map(async (item) => ({
        id: item.id,
        fileName: item.fileName,
        mimeType: item.mimeType,
        sizeBytes: item.sizeBytes,
        createdAt: item.createdAt,
        downloadUrl: await signDownloadUrl(item.storageKey, item.fileName),
      }))
    );

    return NextResponse.json({ media: mediaWithSignedLinks });
  } catch {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }
}
