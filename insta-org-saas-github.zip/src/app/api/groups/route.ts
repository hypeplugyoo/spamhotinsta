import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireIdentity } from "@/lib/auth";
import { createGroupSchema } from "@/lib/domain";

export async function GET() {
  try {
    const identity = await requireIdentity();

    const groups = await prisma.accountGroup.findMany({
      where: { organizationId: identity.organizationId },
      include: {
        profiles: {
          include: {
            profile: {
              select: { id: true, username: true, displayName: true },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      groups: groups.map((g) => ({
        id: g.id,
        name: g.name,
        description: g.description,
        profiles: g.profiles.map((p) => p.profile),
      })),
    });
  } catch {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    const identity = await requireIdentity(["OWNER", "ADMIN", "EDITOR"]);
    const body = await request.json();
    const parsed = createGroupSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { name, description, profileIds } = parsed.data;

    const validProfiles = await prisma.instagramProfile.findMany({
      where: {
        id: { in: profileIds },
        organizationId: identity.organizationId,
      },
      select: { id: true },
    });

    const group = await prisma.accountGroup.create({
      data: {
        organizationId: identity.organizationId,
        name,
        description,
        profiles: {
          create: validProfiles.map((p) => ({ profileId: p.id })),
        },
      },
      include: {
        profiles: {
          include: {
            profile: { select: { id: true, username: true } },
          },
        },
      },
    });

    return NextResponse.json({ group });
  } catch {
    return NextResponse.json(
      { error: "Erro ao criar grupo de contas." },
      { status: 500 }
    );
  }
}
