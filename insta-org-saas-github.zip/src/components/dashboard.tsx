"use client";

import React, { useEffect, useState } from "react";
import { DEMO_METRICS_SNAPSHOT } from "@/worker/metrics";

interface DashboardProps {
  organizationName: string;
  userName: string;
  userRole: string;
}

export function Dashboard({
  organizationName,
  userName,
  userRole,
}: DashboardProps) {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [mediaList, setMediaList] = useState<any[]>([]);

  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [instagramPassword, setInstagramPassword] = useState("");

  const [groupName, setGroupName] = useState("");
  const [groupDesc, setGroupDesc] = useState("");
  const [selectedProfileIds, setSelectedProfileIds] = useState<string[]>([]);

  const [uploading, setUploading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  async function loadWorkspaceData() {
    const [profRes, grpRes, medRes] = await Promise.all([
      fetch("/api/profiles"),
      fetch("/api/groups"),
      fetch("/api/media"),
    ]);
    if (profRes.ok) setProfiles((await profRes.json()).profiles);
    if (grpRes.ok) setGroups((await grpRes.json()).groups);
    if (medRes.ok) setMediaList((await medRes.json()).media);
  }

  useEffect(() => {
    loadWorkspaceData();
  }, []);

  async function handleAddProfile(e: React.FormEvent) {
    e.preventDefault();
    setStatusMessage(null);
    const res = await fetch("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username,
        displayName,
        instagramPassword: instagramPassword || undefined,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setStatusMessage(data.error || "Erro ao cadastrar perfil.");
      return;
    }
    setUsername("");
    setDisplayName("");
    setInstagramPassword("");
    setStatusMessage(`Perfil @${data.profile.username} salvo na organização.`);
    loadWorkspaceData();
  }

  async function handleCreateGroup(e: React.FormEvent) {
    e.preventDefault();
    setStatusMessage(null);
    const res = await fetch("/api/groups", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: groupName,
        description: groupDesc,
        profileIds: selectedProfileIds,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setStatusMessage(data.error || "Erro ao criar grupo.");
      return;
    }
    setGroupName("");
    setGroupDesc("");
    setSelectedProfileIds([]);
    setStatusMessage("Grupo criado com sucesso.");
    loadWorkspaceData();
  }

  async function handlePrivateFileUpload(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setStatusMessage("1/3 Preparando URL assinada privada...");

    try {
      const prepRes = await fetch("/api/media/prepare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: file.name,
          mimeType: file.type,
          sizeBytes: file.size,
        }),
      });
      const prepData = await prepRes.json();
      if (!prepRes.ok) throw new Error(prepData.error);

      setStatusMessage("2/3 Enviando arquivo para o bucket privado S3...");
      const putRes = await fetch(prepData.uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!putRes.ok) throw new Error("Falha no envio para o storage S3.");

      setStatusMessage("3/3 Validando integridade do objeto no S3...");
      const verRes = await fetch("/api/media/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mediaId: prepData.mediaId }),
      });
      const verData = await verRes.json();
      if (!verRes.ok) throw new Error(verData.error);

      setStatusMessage("Mídia validada e disponível com link temporário privado!");
      loadWorkspaceData();
    } catch (err: any) {
      setStatusMessage(err.message || "Falha no fluxo de upload.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  function toggleProfileSelection(id: string) {
    setSelectedProfileIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <span className="text-xs uppercase tracking-wider text-indigo-400 font-semibold">
              Workspace Isolado por Organização
            </span>
            <h1 className="text-2xl font-bold">{organizationName}</h1>
            <p className="text-xs text-slate-400">
              Operador: {userName} • Papel:{" "}
              <strong className="text-slate-200">{userRole}</strong>
            </p>
          </div>

          <button
            onClick={async () => {
              await fetch("/api/auth/logout", { method: "POST" });
              window.location.href = "/login";
            }}
            className="rounded-lg border border-slate-700 px-4 py-2 text-xs hover:bg-slate-900"
          >
            Encerrar Sessão Segura
          </button>
        </header>

        <div className="rounded-xl bg-amber-950/50 border border-amber-700/80 p-4 flex items-start justify-between gap-4">
          <div>
            <span className="inline-block text-xs font-bold uppercase tracking-wider bg-amber-500 text-slate-950 px-2 py-0.5 rounded mb-1">
              Modo Demonstração (Dados Simulados)
            </span>
            <p className="text-sm text-amber-200">
              Os indicadores de alcance, impressões e engajamento exibidos nos
              cards abaixo são <strong>dados estáticos de demonstração</strong>{" "}
              (definidos em <code>metrics.ts</code>) e ainda não refletem
              coletas reais da API do Instagram. Já os perfis, grupos e mídias
              abaixo são gravados de forma real e isolada no banco e S3 da sua
              organização.
            </p>
          </div>
        </div>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {DEMO_METRICS_SNAPSHOT.map((item) => (
            <div
              key={item.profileUsername}
              className="rounded-xl bg-slate-900 border border-slate-800 p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="font-semibold text-indigo-400">
                  {item.profileUsername}
                </span>
                <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                  DEMO
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-slate-400 text-xs">Seguidores (Demo)</p>
                  <p className="font-bold text-lg">
                    {item.followersCount.toLocaleString("pt-BR")}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-xs">Alcance 7d (Demo)</p>
                  <p className="font-bold text-lg">
                    {item.reachLast7d.toLocaleString("pt-BR")}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-xs">Engajamento (Demo)</p>
                  <p className="font-semibold text-emerald-400">
                    {item.engagementRate}%
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-xs">Posts 7d (Demo)</p>
                  <p className="font-semibold">{item.postsPublishedLast7d}</p>
                </div>
              </div>
            </div>
          ))}
        </section>

        {statusMessage && (
          <div className="rounded-lg bg-indigo-950/60 border border-indigo-700 px-4 py-3 text-sm text-indigo-200">
            {statusMessage}
          </div>
        )}

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-lg font-bold">
              1. Perfis do Instagram ({profiles.length})
            </h2>
            <p className="text-xs text-slate-400">
              Cadastre apenas com o <code>@username</code> para organizar seus
              grupos ou informe também a senha para autenticar o worker de
              postagem.
            </p>

            <form onSubmit={handleAddProfile} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="@usuario_do_insta"
                  className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                />
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Apelido interno (opcional)"
                  className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                />
              </div>
              <input
                type="password"
                value={instagramPassword}
                onChange={(e) => setInstagramPassword(e.target.value)}
                placeholder="Senha do Instagram (Opcional — criptografada com AES-256)"
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                className="rounded-lg bg-indigo-600 hover:bg-indigo-500 px-4 py-2 text-xs font-semibold"
              >
                Salvar Perfil na Organização
              </button>
            </form>

            <ul className="divide-y divide-slate-800 text-sm max-h-52 overflow-y-auto">
              {profiles.map((p) => (
                <li
                  key={p.id}
                  className="py-2.5 flex items-center justify-between"
                >
                  <div>
                    <span className="font-medium text-slate-100">
                      @{p.username}
                    </span>
                    {p.displayName && (
                      <span className="text-xs text-slate-400 ml-2">
                        ({p.displayName})
                      </span>
                    )}
                  </div>
                  <span
                    className={`text-[11px] px-2 py-0.5 rounded ${
                      p.hasCredentials
                        ? "bg-emerald-950 text-emerald-300 border border-emerald-800"
                        : "bg-slate-800 text-slate-300"
                    }`}
                  >
                    {p.hasCredentials
                      ? "Login Direto Configurado"
                      : "Somente @username"}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 className="text-lg font-bold">
              2. Grupos de Contas ({groups.length})
            </h2>
            <p className="text-xs text-slate-400">
              Agrupe perfis por nicho ou campanha para disparo em lote.
            </p>

            <form onSubmit={handleCreateGroup} className="space-y-3">
              <input
                type="text"
                required
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Nome do Grupo (Ex: Contas de Ofertas SP)"
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
              />
              <input
                type="text"
                value={groupDesc}
                onChange={(e) => setGroupDesc(e.target.value)}
                placeholder="Descrição (opcional)"
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
              />

              <div className="text-xs text-slate-300">
                Selecionar perfis do grupo:
                <div className="flex flex-wrap gap-2 mt-2">
                  {profiles.map((p) => (
                    <button
                      type="button"
                      key={p.id}
                      onClick={() => toggleProfileSelection(p.id)}
                      className={`px-2.5 py-1 rounded-full border text-xs ${
                        selectedProfileIds.includes(p.id)
                          ? "bg-indigo-600 border-indigo-500 text-white"
                          : "bg-slate-950 border-slate-800 text-slate-400"
                      }`}
                    >
                      @{p.username}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="rounded-lg bg-indigo-600 hover:bg-indigo-500 px-4 py-2 text-xs font-semibold"
              >
                Criar Grupo
              </button>
            </form>

            <ul className="divide-y divide-slate-800 text-sm max-h-52 overflow-y-auto">
              {groups.map((g) => (
                <li key={g.id} className="py-2.5">
                  <div className="font-medium">{g.name}</div>
                  <div className="text-xs text-slate-400">
                    {g.profiles.length > 0
                      ? g.profiles.map((p: any) => `@${p.username}`).join(", ")
                      : "Nenhum perfil vinculado"}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold">
                3. Biblioteca de Mídias Privadas ({mediaList.length})
              </h2>
              <p className="text-xs text-slate-400">
                Upload seguro via URL pré-assinada (`prepare` → `PUT S3` →
                `verify`) e download via link temporário privado (expira em 15
                minutos).
              </p>
            </div>

            <label className="cursor-pointer rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-xs font-semibold">
              {uploading ? "Enviando..." : "+ Enviar Nova Mídia Privada"}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp,video/mp4"
                onChange={handlePrivateFileUpload}
                disabled={uploading}
                className="hidden"
              />
            </label>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2">Arquivo</th>
                  <th className="py-2">Tipo</th>
                  <th className="py-2">Tamanho</th>
                  <th className="py-2 text-right">Ação Privada</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {mediaList.map((m) => (
                  <tr key={m.id}>
                    <td className="py-3 font-medium">{m.fileName}</td>
                    <td className="py-3 text-xs text-slate-400">{m.mimeType}</td>
                    <td className="py-3 text-xs text-slate-400">
                      {(m.sizeBytes / 1024).toFixed(1)} KB
                    </td>
                    <td className="py-3 text-right">
                      <a
                        href={m.downloadUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-indigo-400 hover:underline font-medium"
                      >
                        Baixar via Link Temporário
                      </a>
                    </td>
                  </tr>
                ))}
                {mediaList.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-6 text-center text-slate-500">
                      Nenhuma mídia verificada nesta organização ainda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
