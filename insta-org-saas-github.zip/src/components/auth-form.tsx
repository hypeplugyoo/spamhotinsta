"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";

interface AuthFormProps {
  mode: "login" | "register";
}

export function AuthForm({ mode }: AuthFormProps) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [organizationName, setOrganizationName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const endpoint =
      mode === "register" ? "/api/auth/register" : "/api/auth/login";

    const payload =
      mode === "register"
        ? { name, organizationName, email, password }
        : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Falha ao autenticar.");
        setLoading(false);
        return;
      }

      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Erro de conexão com o servidor.");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl">
        <h1 className="text-2xl font-bold mb-2">
          {mode === "register"
            ? "Criar Conta e Organização"
            : "Entrar no Painel"}
        </h1>
        <p className="text-sm text-slate-400 mb-6">
          {mode === "register"
            ? "No primeiro acesso, criamos seu workspace totalmente isolado."
            : "Acesse o ambiente seguro da sua organização."}
        </p>

        {error && (
          <div className="mb-4 rounded-lg bg-red-950/60 border border-red-800 px-4 py-3 text-sm text-red-200">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Seu Nome
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Gabriel Ferraz"
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Nome da Organização (Workspace)
                </label>
                <input
                  type="text"
                  required
                  value={organizationName}
                  onChange={(e) => setOrganizationName(e.target.value)}
                  placeholder="Ex: Agência Vórtex Digital"
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              E-mail
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@empresa.com.br"
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Senha
            </label>
            <input
              type="password"
              required
              minLength={mode === "register" ? 8 : 1}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 py-2.5 text-sm font-semibold transition"
          >
            {loading
              ? "Processando..."
              : mode === "register"
              ? "Criar Organização e Acessar"
              : "Entrar na Organização"}
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-slate-400">
          {mode === "register" ? (
            <>
              Já possui uma organização?{" "}
              <a href="/login" className="text-indigo-400 hover:underline">
                Fazer login
              </a>
            </>
          ) : (
            <>
              Ainda não tem conta?{" "}
              <a href="/registro" className="text-indigo-400 hover:underline">
                Criar organização
              </a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
