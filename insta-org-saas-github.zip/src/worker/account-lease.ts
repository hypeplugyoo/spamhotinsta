import crypto from "crypto";
import { redisConnection } from "./queues";

export class AccountLeaseManager {
  private prefix = "ig:account:lease:";

  async acquireLease(profileId: string, ttlMs = 120_000): Promise<string | null> {
    const token = crypto.randomUUID();
    const key = `${this.prefix}${profileId}`;
    const result = await redisConnection.set(key, token, "PX", ttlMs, "NX");
    return result === "OK" ? token : null;
  }

  async releaseLease(profileId: string, token: string): Promise<boolean> {
    const key = `${this.prefix}${profileId}`;
    const luaScript = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
      else
        return 0
      end
    `;
    const released = await redisConnection.eval(luaScript, 1, key, token);
    return released === 1;
  }
}

export const accountLease = new AccountLeaseManager();
