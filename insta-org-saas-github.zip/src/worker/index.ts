import { Worker } from "bullmq";
import { prisma } from "@/lib/db";
import { signDownloadUrl } from "@/lib/s3";
import {
  PublicationJobPayload,
  MetricSyncJobPayload,
  redisConnection,
} from "./queues";
import { accountLease } from "./account-lease";
import { instagramAdapter } from "./instagram-adapter";

export const publicationWorker = new Worker<PublicationJobPayload>(
  "instagram-publications",
  async (job) => {
    const { publicationJobId, organizationId, profileId, mediaId, caption } =
      job.data;

    const leaseToken = await accountLease.acquireLease(profileId, 120_000);
    if (!leaseToken) {
      throw new Error("CONTA_EM_USO_POR_OUTRO_WORKER");
    }

    try {
      await prisma.publicationJob.update({
        where: { id: publicationJobId },
        data: { status: "PROCESSING" },
      });

      const media = await prisma.mediaAsset.findFirst({
        where: { id: mediaId, organizationId, status: "READY" },
      });

      if (!media) {
        throw new Error("MIDIA_NAO_DISPONIVEL_OU_DE_OUTRA_ORGANIZACAO");
      }

      const signedUrl = await signDownloadUrl(media.storageKey, media.fileName);

      await instagramAdapter.publishMedia({
        organizationId,
        profileId,
        mediaDownloadUrl: signedUrl,
        caption,
      });

      await prisma.publicationJob.update({
        where: { id: publicationJobId },
        data: { status: "COMPLETED", publishedAt: new Date() },
      });
    } catch (err: any) {
      await prisma.publicationJob.update({
        where: { id: publicationJobId },
        data: {
          status: "FAILED",
          errorMessage: err?.message ?? "Erro desconhecido",
        },
      });
      throw err;
    } finally {
      await accountLease.releaseLease(profileId, leaseToken);
    }
  },
  { connection: redisConnection, concurrency: 5 }
);

export const metricsWorker = new Worker<MetricSyncJobPayload>(
  "instagram-metrics",
  async (job) => {
    const { profileId } = job.data;
    const leaseToken = await accountLease.acquireLease(profileId, 60_000);
    if (!leaseToken) return;

    try {
      console.log(`[Worker] Coletando métricas para o perfil ${profileId}`);
    } finally {
      await accountLease.releaseLease(profileId, leaseToken);
    }
  },
  { connection: redisConnection, concurrency: 3 }
);

console.log("[Worker] Background runtime iniciado (BullMQ + Account Lease ativos).");
