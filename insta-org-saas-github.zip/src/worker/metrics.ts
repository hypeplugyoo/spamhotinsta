export interface AccountMetricSnapshot {
  profileUsername: string;
  followersCount: number;
  impressionsLast7d: number;
  reachLast7d: number;
  engagementRate: number;
  postsPublishedLast7d: number;
  isDemoData: boolean;
}

export const DEMO_METRICS_SNAPSHOT: AccountMetricSnapshot[] = [
  {
    profileUsername: "@loja.vitrine.sp",
    followersCount: 48200,
    impressionsLast7d: 194500,
    reachLast7d: 112300,
    engagementRate: 4.8,
    postsPublishedLast7d: 14,
    isDemoData: true,
  },
  {
    profileUsername: "@achadinhos.oferta.br",
    followersCount: 129400,
    impressionsLast7d: 610200,
    reachLast7d: 405000,
    engagementRate: 6.2,
    postsPublishedLast7d: 28,
    isDemoData: true,
  },
  {
    profileUsername: "@catalogo.moda.premium",
    followersCount: 19850,
    impressionsLast7d: 54300,
    reachLast7d: 38900,
    engagementRate: 3.9,
    postsPublishedLast7d: 9,
    isDemoData: true,
  },
];
