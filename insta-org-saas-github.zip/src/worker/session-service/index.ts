import { prisma } from "@/lib/db";
import { decryptSecret, encryptSecret } from "@/lib/crypto";

export class InstagramSessionService {
  async loadCredentialsAndSession(profileId: string, organizationId: string) {
    const profile = await prisma.instagramProfile.findFirst({
      where: { id: profileId, organizationId },
    });

    if (!profile) throw new Error("PERFIL_NAO_ENCONTRADO_NA_ORGANIZACAO");

    return {
      username: profile.username,
      password: profile.encryptedPassword
        ? decryptSecret(profile.encryptedPassword)
        : null,
      serializedSession: profile.encryptedSession
        ? decryptSecret(profile.encryptedSession)
        : null,
    };
  }

  async saveSerializedSession(profileId: string, sessionJson: string) {
    await prisma.instagramProfile.update({
      where: { id: profileId },
      data: {
        encryptedSession: encryptSecret(sessionJson),
        sessionUpdatedAt: new Date(),
      },
    });
  }
}

export const instagramSessionService = new InstagramSessionService();
