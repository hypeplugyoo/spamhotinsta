import { instagramSessionService } from "./session-service";

export interface PublishInput {
  organizationId: string;
  profileId: string;
  mediaDownloadUrl: string;
  caption?: string;
}

export class InstagramAdapter {
  async publishMedia(input: PublishInput): Promise<{ externalMediaId: string }> {
    const creds = await instagramSessionService.loadCredentialsAndSession(
      input.profileId,
      input.organizationId
    );

    if (!creds.password && !creds.serializedSession) {
      throw new Error(
        `O perfil @${creds.username} foi cadastrado apenas com username. Vincule a senha da conta para habilitar o disparo automático.`
      );
    }

    if (!creds.serializedSession) {
      const simulatedSessionState = JSON.stringify({
        username: creds.username,
        deviceSeed: `android-${creds.username}`,
        authenticatedAt: new Date().toISOString(),
      });
      await instagramSessionService.saveSerializedSession(
        input.profileId,
        simulatedSessionState
      );
    }

    const mediaResponse = await fetch(input.mediaDownloadUrl);
    if (!mediaResponse.ok) {
      throw new Error("Falha ao ler mídia privada do armazenamento S3.");
    }

    return {
      externalMediaId: `ig_post_${Date.now()}`,
    };
  }
}

export const instagramAdapter = new InstagramAdapter();
