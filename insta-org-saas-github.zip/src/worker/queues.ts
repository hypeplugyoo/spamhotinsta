import { Queue } from "bullmq";
import IORedis from "ioredis";

export const redisConnection = new IORedis(
  process.env.REDIS_URL || "redis://localhost:6379",
  {
    maxRetriesPerRequest: null,
  }
);

export interface PublicationJobPayload {
  publicationJobId: string;
  organizationId: string;
  profileId: string;
  mediaId: string;
  caption?: string;
}

export interface MetricSyncJobPayload {
  organizationId: string;
  profileId: string;
}

export const publicationQueue = new Queue<PublicationJobPayload>(
  "instagram-publications",
  { connection: redisConnection }
);

export const metricsQueue = new Queue<MetricSyncJobPayload>(
  "instagram-metrics",
  { connection: redisConnection }
);
